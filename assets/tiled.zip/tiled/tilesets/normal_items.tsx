<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="normal_items" tilewidth="32" tileheight="32" tilecount="512" columns="16">
 <image source="../atlases/normal_items.png" width="512" height="1024"/>
 <tile id="0">
  <properties>
   <property name="name" value="bandage"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="name" value="shotgun_ammo"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="name" value="10mm_fmj"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="name" value="pills"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="name" value="7.65mm"/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="name" value="beef"/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="name" value="deagle_44"/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="name" value="medkit"/>
  </properties>
 </tile>
 <tile id="8">
  <properties>
   <property name="name" value="watches"/>
  </properties>
 </tile>
 <tile id="9">
  <properties>
   <property name="name" value="bullet"/>
  </properties>
 </tile>
 <tile id="10">
  <properties>
   <property name="name" value="unknown"/>
  </properties>
 </tile>
</tileset>
